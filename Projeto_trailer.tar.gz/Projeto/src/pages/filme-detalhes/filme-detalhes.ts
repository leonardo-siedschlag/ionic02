import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { MovieProvider } from '../../providers/movie/movie';


/**
 * Generated class for the FilmeDetalhesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-filme-detalhes',
  templateUrl: 'filme-detalhes.html',
  // providers:[MovieProvider]
})
export class FilmeDetalhesPage {
  public filme;
  public filmeId;
  public trailer;
  
  // public movieProvider:MovieProvider;
  constructor(public navCtrl: NavController, public navParams: NavParams, 
    public movieProvider: MovieProvider,public http:HttpClient) {
  }

  ionViewDidLoad() {
    this.filmeId = this.navParams.get("id");//isso vem la do feed.ts
                                          //pegando o parametro id da funcao abrirDetalhes
   
  this.movieProvider.PegaId(this.filmeId).subscribe(//RECEBER RESPOSTA DO WEB    
                                                    //HTTP E UM OBSERVABLE    
    data=>{
        
        this.filme = data
        //console.log("retorno com sucesso")
        //console.log(data)

    },error=>{

      console.log("erro")
    }
  )
   
  this.movieProvider.PegaTrailer(this.filmeId).subscribe(

      data=>{
        let obj = data as any
        
        
        this.trailer = obj.results[0];   
        console.log(this.trailer)
      },error=>{

        console.log("deu ruim")
      }
  ) 
  
  this.movieProvider.YouTube().subscribe(

    data=>{

       let obj = data as any
       obj + "this.trailer"
       console.log(obj)

    },error=>{


    }

  )  
}



}



//*videos:any =[


     // {
        //title:this.trailer.title,

       // video:'https://www.youtube.com/watch?v=' + this.trailer
          
     // }
//]


